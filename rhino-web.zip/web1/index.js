
const { RhionModules } = require('./local-module/rhion-module')

var server = new RhionModules({
  path: 'modules',
  defaultTitle: 'Home',
  titlePrefix: 'Rhion:',
  titleSuffix: '',
  https: false,
  __rootFolder: __dirname
})
server.Start()
// server.Application.use((ctx, next) => {
//   console.log(ctx.request.path)
//   next()
// })

//server.Application.listen(3001)
