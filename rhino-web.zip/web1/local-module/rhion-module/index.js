const Koa = require('koa')
const fs = require('fs')
const path = require('path')
const RhionModule = require('./lib/rhion-module')
const fileSystem = require('./lib/filesystem')
const Router = require('./lib/router')
const { UID, _util } = require('./lib/util')
const Template = require('./lib/template')
const Helper = require('./lib/helpers')
const logger = require('./lib/logger')
const http = require('http')
const serve = require('./lib/middlerwares/static')
const isajax = require('koa-isajax')
// const https = require('https')

const ROUTER_PATH = 'routers'

let rootRouter = new Router()
// let Application= new Koa();

const defaultOptions = {
  theme: 'default',
  layout: 'index',
  defaultTitle: '',
  titlePrefix: '',
  titleSuffix: '',
  port: '3001',
  host: 'localhost',
  environment: ''
}
/**
 * @module
 */
module.exports = {
  RhionModules: RhionModules,
  Router: Router
}
/**
 * @alias module:rhion-module
 * @param {Object=} options
 * @param {String=} options.path
 * @param {Koa=} koaApp
 */
function RhionModules (options) {
  if (!(this instanceof RhionModules)) {
    return RhionModules(options)
  }

  let self = this
  this.options = Object.assign({}, defaultOptions, options)
  this.modules = _util.uniq()
  this.Application = new Koa()
  this.Template = new Template({
    cache: true,
    Templateid: _util.now()
  })
  this.helpers = new Helper(this.options)

  this.LoadModules(this.options.path, function (err, rhmodule) {
    if (!err) {
      self.AddModule(rhmodule)
      self.ApplyModuleRouter(rhmodule)
    }
  })
  this.Application.context.render = async function (view, data, layout) {
    const ctx = this
    let currentModule = self.getModule(this.matched[0].moduleId)
    if (!currentModule) {
      logger.error(`Module Not Found ${this.matched[0].moduleId}`)
    } else {
      try {
        data = Object.assign({}, ctx.state, data, self.helpers)
        layout = layout || self.options.layout
        let viewPath = path.resolve(currentModule.modulePath, currentModule.Views)
        let layoutPath = path.resolve(process.cwd(), 'themes', self.options.theme)
        data.htmlHelper = self.helpers // Base Html Helper Added
        let html = await self.Template.render(view, viewPath, data)
        if (!isajax) {
          data.title = getPageTitle(data)
          data.body = html
          html = await self.Template.render(layout, layoutPath, data)
        }
        // console.log(html)
        // ctx.type = 'html'
        ctx.body = html
      } catch (err) {
        logger.error(`Application.context.render - ${err}`)
        ctx.body = ''
      }
    }
  }

  function getPageTitle (data) {
    return self.options.titlePrefix + (data.title ? data.title : self.options.defaultTitle) + self.options.titleSuffix
  }
}

RhionModules.prototype.getModule = function (moduleId) {
  // moduleId='12';
  let m = _util.find(this.modules, function (item) {
    return item.moduleId === moduleId
  })
  return m
}

RhionModules.prototype.Modules = function () {
  let dispatch = function dispatch (ctx, next) {

  }

  return dispatch
}

RhionModules.prototype.ApplyModuleRouter = function (m) {
  //  console.log(m);
  var routerPath = path.resolve(m.modulePath, ROUTER_PATH)

  var routers = fileSystem.getFileList(routerPath)
  routers.forEach(function (value) {
    rootRouter.use(m.prefix, require(value).routes(m.moduleId))
  })
}
/**
 * @param {RhionModule} rhionModule
 */
RhionModules.prototype.AddModule = function (rhionModule) {
  this.modules.push(rhionModule)
}

RhionModules.prototype.LoadModules = function (modulePath, done) {
  var rhionModules = this
  rhionModules.modulePath = path.resolve(process.cwd(), modulePath)
  fs.readdir(rhionModules.modulePath, function (err, items) {
    if (err) return done(err)
    items.forEach((file) => {
      // console.log(rhionModules.modulePath +'-'+file);
      file = path.resolve(rhionModules.modulePath, file)
      if (fs.statSync(file).isDirectory()) {
        let pkg = path.resolve(rhionModules.modulePath, file, 'package.json')
        // console.log('pkg-'+pkg);
        if (fs.existsSync(pkg)) {
          let rowData = fs.readFileSync(pkg)
          // console.log(rowData);
          let data = JSON.parse(rowData)
          // console.log(data);
          data.modulePath = path.resolve(this.rhionModules, file)
          data.moduleId = UID()
          done(null, new RhionModule(data))
          // rhionModules.AddModule(new RhionModule(data));
        }
      }
    })
  })
}

RhionModules.prototype.Start = function () {
  // console.log(this.options.__rootFolder + '/themes')
  this.Application.use(serve('themes'))
  this.Application.use(rootRouter.routes())
  // this.Application.listen(this.options.port)
  return http.createServer(this.Application.callback()).listen(this.options.port, this.options.host)
}
