const { Router } = require('../../../local-module/rhion-module')
// const Router=require('rhion-router-view');

let route = new Router()

route.get('/', async (ctx, next) => {
  // route.render("Test");
  ctx.body = 'ctx.render("user")'
  // ctx.body="test";
})

route.get('/user', async (ctx, next) => {
  // route.render("user");
  let user = {
    'userId': 'sam123',
    'password': 'password 2'
  }
  // console.log(`router${html}`);
  await ctx.render('user', user)
})
route.get('/abc', async (ctx, next) => {
  // route.render("abc");
  ctx.body = ctx.render('abc')
})
route.get('/ccc', async (ctx, next) => {
  // route.render("ccc");
  ctx.body = ctx.render('ccc')
})

module.exports = route
