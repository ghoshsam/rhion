var gulp = require('gulp')
var sass = require('gulp-sass')
var sourcemap = require('gulp-sourcemaps')
var cleancss = require('gulp-clean-css')
var rename = require('gulp-rename')
var postcss = require('gulp-postcss')
var autoprefixer = require('autoprefixer')

gulp.task('build-theme', function () {
  return gulp.src(['themes/**/style.scss'])
    .pipe(sourcemap.init())
    .pipe(sass().on('error', sass.logError))
    .pipe(postcss([autoprefixer({
      browsers: [
        'Chrome >= 35',
        'Firefox >= 38',
        'Edge >= 12',
        'Explorer >= 10',
        'iOS >= 8',
        'Safari >= 8',
        'Android 2.3',
        'Android >= 4',
        'Opera >= 12'
      ]
    })]))
    .pipe(sourcemap.write())
    .pipe(gulp.dest('./themes/'))
    .pipe(cleancss())
    .pipe(rename({ suffix: '.min' }))
    .pipe(gulp.dest('./themes/'))
})

// gulp.task('watch', ['build-theme'], function () {
//   gulp.watch(['themes/*.scss'], ['build-theme'])
// })

gulp.task('watch', gulp.series('build-theme', function () {
  gulp.watch(['themes/**/*.scss'], ['build-theme'])
}))
gulp.task('default', gulp.series('build-theme', function (done) {
  done()
}))
